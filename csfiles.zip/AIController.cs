using UnityEngine;

public class AIController : MonoBehaviour
{
    public void ApplyFatEffect(float value)
    {
        // 살찌는 효과 구현
    }

    public void ApplySlimEffect(float value)
    {
        // 살빼는 효과 구현
    }
    public float baseSpeed = 5f; // 기본 속도
    private float currentSpeed;
    private GameObject heldItem; // 현재 소지 중인 아이템

    void Start()
    {
        // 랜덤 속도 설정
        currentSpeed = baseSpeed + Random.Range(-0.5f, 1f); // 기본 속도 ± 랜덤값
    }

    void Update()
    {
        // 자동으로 앞으로 이동
        transform.Translate(Vector3.forward * currentSpeed * Time.deltaTime);

        // 랜덤하게 좌우로 움직임
        float randomX = Random.Range(-0.1f, 0.1f);
        transform.Translate(new Vector3(randomX, 0, 0) * Time.deltaTime);
    }

    private void OnTriggerEnter(Collider other)
    {
        // 아이템과 충돌했을 때
        if (other.CompareTag("Item"))
        {
            PickUpItem(other.gameObject); // 아이템 소지
        }
    }

    void PickUpItem(GameObject item)
    {
        if (heldItem != null)
        {
            Destroy(heldItem); // 기존 아이템 제거
        }

        heldItem = item;
        heldItem.SetActive(false); // 아이템 비활성화
        Debug.Log($"{heldItem.name}을(를) 소지했습니다!");

        // 일정 시간 후 자동으로 사용 또는 던지기
        Invoke("UseOrThrowItem", Random.Range(2f, 5f));
    }

    void UseOrThrowItem()
    {
        if (heldItem == null)
        {
            return;
        }

        if (Random.value > 0.5f)
        {
            UseItem(); // 아이템 사용
        }
        else
        {
            ThrowItem(); // 아이템 던지기
        }
    }

    void UseItem()
    {
        if (heldItem == null)
        {
            Debug.Log("소지한 아이템이 없습니다!");
            return;
        }

        // 소지한 아이템의 효과 적용
        ItemEffect itemEffect = heldItem.GetComponent<ItemEffect>();
        if (itemEffect != null)
        {
            itemEffect.ApplyEffect(this); // 아이템 효과 적용
        }

        // 아이템 제거
        Destroy(heldItem);
        heldItem = null;
        Debug.Log("아이템을 사용했습니다!");
    }

    void ThrowItem()
    {
        if (heldItem == null)
        {
            Debug.Log("소지한 아이템이 없습니다!");
            return;
        }

        // 아이템 던지기
        heldItem.SetActive(true); // 아이템 활성화
        heldItem.transform.position = transform.position + transform.forward * 2; // 앞쪽으로 던지기
        heldItem.transform.rotation = Quaternion.identity;
        heldItem.GetComponent<Rigidbody>().linearVelocity = transform.forward * 10f; // 던지는 힘 적용
        heldItem = null; // 소지 해제
        Debug.Log("아이템을 던졌습니다!");
    }

    public void ChangeSpeed(float modifier)
    {
        currentSpeed += modifier; // 속도 변경
    }
}