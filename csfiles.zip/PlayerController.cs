using UnityEngine;
using UnityEngine.Audio;

public class PlayerController : MonoBehaviour
{

    public float speed = 4f; // 기본 속도
    private int fatCount = 0; // 살찌는 횟수
    private bool isSlim = false; // 살빠진 상태인지 확인

    private GameObject heldItem; // 현재 소지 중인 아이템
    public ParticleSystem pickUpEffect; // 아이템 먹기 파티클 효과
    public AudioClip itemPickupSound; // 아이템 먹기 사운드
    private AudioSource audioSource;
    void Start()
    {
        audioSource = GetComponent<AudioSource>();
    }
    void Update()
    {
        // 자동으로 앞으로 이동
        transform.Translate(Vector3.forward * speed * Time.deltaTime);

        // 아이템 사용(E), 던지기(T) 액션
        if (Input.GetKeyDown(KeyCode.E))
        {
            UseItem();
        }
        if (Input.GetKeyDown(KeyCode.T))
        {
            ThrowItem();
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        Debug.Log($"충돌 감지됨: {other.name}");
        // 아이템과 충돌했을 때
        if (other.CompareTag("Item"))
        {
            Debug.Log($"아이템 감지됨: {other.name}");
            ItemEffect itemEffect = other.GetComponent<ItemEffect>();
            if (itemEffect != null)
            {
                PickUpItem(other.gameObject); // 아이템 소지
            }
        }
    }

    void PickUpItem(GameObject newItem)
    {
        // 기존 아이템이 있다면 제거
        if (heldItem != null)
        {
            Debug.Log("새 아이템을 소지합니다. 기존 아이템을 제거합니다.");
            Destroy(heldItem); // 기존 아이템 제거
        }

        // 새 아이템을 소지
        heldItem = newItem;
        heldItem.SetActive(false); // 아이템 비활성화
        Debug.Log($"{heldItem.name}을(를) 소지했습니다!");

        // 사운드 재생
        if (itemPickupSound != null && audioSource != null)
        {
            audioSource.PlayOneShot(itemPickupSound);
        }

        Debug.Log($"{heldItem.name}을(를) 소지했습니다!");
    }

    void UseItem()
    {
        if (heldItem == null)
        {
            Debug.Log("소지한 아이템이 없습니다!");
            return;
        }

        // 소지한 아이템의 효과 적용
        ItemEffect itemEffect = heldItem.GetComponent<ItemEffect>();
        if (itemEffect != null)
        {
            itemEffect.ApplyEffect(this); // 아이템 효과 적용
        }

        // 아이템 제거
        Destroy(heldItem);
        heldItem = null;
        Debug.Log("아이템을 사용했습니다!");
    }

    void ThrowItem()
    {
        if (heldItem == null)
        {
            Debug.Log("소지한 아이템이 없습니다!");
            return;
        }

        // 아이템 던지기
        heldItem.SetActive(true); // 아이템 활성화
        heldItem.transform.position = transform.position + transform.forward * 2; // 앞쪽으로 던지기
        heldItem.transform.rotation = Quaternion.identity;
        heldItem.GetComponent<Rigidbody>().linearVelocity = transform.forward * 10f; // 던지는 힘 적용
        heldItem = null; // 소지 해제
        Debug.Log("아이템을 던졌습니다!");
    }

    public void ApplyFatEffect(float value)
    {
        if (fatCount < 5) // 최대 5번까지만 살찌도록 제한
        {
            fatCount++;
            transform.localScale += new Vector3(value, value, value); // 크기 증가
            speed -= value * 2; // 속도 감소
            Debug.Log($"살찌는 효과 적용! 크기: {transform.localScale}, 속도: {speed}");
        }
        else
        {
            Debug.Log("더 이상 살찔 수 없습니다!");
        }
    }

    public void ApplySlimEffect(float value)
    {
        if (!isSlim) // 한 번만 살빼기 효과를 받도록 제한
        {
            isSlim = true;
            transform.localScale = new Vector3(1, 1, 1); // 원래 크기로 복귀
            speed += value * 2; // 속도 증가
            Debug.Log($"살빼는 효과 적용! 크기: {transform.localScale}, 속도: {speed}");
        }
        else
        {
            Debug.Log("이미 살빠진 상태입니다!");
        }
    }
}